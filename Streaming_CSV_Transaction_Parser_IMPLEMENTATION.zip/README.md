# Streaming CSV Transaction Parser

Python 3.12+ local streaming CSV/gzip validation with explicit operator policy, exact monetary totals, recoverable rejected records, and durable completion markers.

**Implementation and local verification are complete. Production acceptance remains pending the required 100/150 GB tests on an 8 GB Linux host and independent review. Human release approval is NOT_GRANTED.**

Verified on Python 3.12.14 and 3.13.5: 41 tests, 100% executable application/utility line coverage, and 100% measured branch coverage. Verification also includes generated CSV/Decimal comparisons, stateful/model tests, five detected code mutations, race/termination tests, a small Lean proof, and offline installation of a byte-reproducible wheel. None of those substitutes for the required target-host scale test.

```sh
python3 main.py --input transactions.csv --output /existing/private-parent/new-run --schema approved-policy.json
python3 -m unittest discover -s tests -v
python3 codex/tools/coverage_gate.py --root . --source main.py --source src/streaming_csv_parser --source tools --tests tests --json-out evidence/coverage_first.json
```

Processing needs only Python's standard library. Verification dependencies are pinned in `pyproject.toml`. The returned ZIP includes Linux x86-64 verification wheels for Python 3.12 and 3.13 under `wheelhouse/` and distributions under `distribution/` for offline use. See [operations](docs/operations.md), [recovery](docs/recovery.md), [benchmarks](docs/benchmarks.md), and the [implementation receipt](IMPLEMENTATION_RECEIPT.json).

The owner contract and supplied acceptance tests remain unchanged. With explicit user authorization, the coverage tool's source measurement was corrected to handle Python files while preserving its threshold, source selection, no-mock scan and exclusions policy. Original handoff statuses remain historical; current implementation results are in `evidence/`.
