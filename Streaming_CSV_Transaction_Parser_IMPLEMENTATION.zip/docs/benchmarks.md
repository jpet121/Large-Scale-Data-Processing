# Measured benchmarks

These are real synthetic files on the current Linux host, not the required 100/150 GB acceptance runs. Each child used a **128 MiB RLIMIT_AS address-space cap**; observed host RAM was approximately 33 GiB. Counts and exact monetary totals matched independently generated references.

| Rows | Format | Actual input bytes | Wall seconds | Kernel peak RSS (KiB) | Rows/second |
|---:|---|---:|---:|---:|---:|
| 1,000 | .csv | 149,084 | 0.101 | 13,440 | 9,895 |
| 100,000 | .csv | 14,900,084 | 1.412 | 13,440 | 70,834 |
| 1,000,000 | .csv | 149,000,084 | 13.834 | 13,440 | 72,284 |
| 100,000 | .csv.gz | 1,046,890 | 1.509 | 13,824 | 66,266 |

Peak RSS stayed approximately flat over this measured ladder. The million-row plain file (149,000,084 bytes) exceeded the 128 MiB process address-space cap, but did **not** exceed total host RAM. It does not establish the owner’s larger-than-host-RAM requirement. Gzip file size is the compressed physical size; rows represent the decompressed data.

Raw `/proc` samples, kernel wait4 RSS, input hashes, references, interpreter details and child logs are in `evidence/benchmarks.json`. Wall time includes process startup and final output hashing; input hashing precedes that timed region. Single runs are observations, not statistical guarantees or performance commitments.

Required 100 GB and >=150 GB physical files on an 8 GB Linux host were **NOT RUN**: available filesystem capacity is below 100 GB and the supplied host is not the specified 8 GB configuration. A source plus accepted output also requires additional storage. No sparse files, virtual byte streams or extrapolations are presented as acceptance evidence. Re-run the supplied generator/benchmark harness on the target system with sufficient source/output space before acceptance.
